

	// функция для показа модального окна
	function showModal(modalId) {
		var modal = document.getElementById(modalId);
		modal.style.display = "block";
	}

	// функция для скрытия модального окна
	function hideModal(modalId) {
		var modal = document.getElementById(modalId);
		modal.style.display = "none";
	}

